<div class="py-6 px-6 text-center">
          <p class="mb-0 fs-4">Design and Developed by Leonardo Distributed by Zento</p>
        </div>
      </div>
    </div>
  </div>
  <script src="<?=base_url('libs/jquery/dist/jquery.min.js')?>"></script>
  <script src="<?=base_url('libs/bootstrap/dist/js/bootstrap.bundle.min.js')?>"></script>
  <script src="<?=base_url('/js/sidebarmenu.js')?>"></script>
  <script src="<?=base_url('/js/app.min.js')?>"></script>
  <script src="<?=base_url('libs/apexcharts/dist/apexcharts.min.js')?>"></script>
  <script src="<?=base_url('libs/simplebar/dist/simplebar.js')?>"></script>
  <script src="<?=base_url('/js/dashboard.js')?>"></script>
</body>

</html>